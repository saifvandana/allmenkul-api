<?php
/*
Theme Name: OSClass Zara Premium Theme
Theme URI: https://osclasspoint.com/osclass-themes/general/zara-osclass-theme_i64
Description: This is the Premium OSClass Zara Theme, most powerful theme for osclass
Version: 1.6.1
Author: MB Themes
Author URI: https://osclasspoint.com/
Widgets: header,footer
Theme update URI: zara-theme-full-responsive
Product Key: 8BBAzI3IDIcFYqA1alzu
*/
?>