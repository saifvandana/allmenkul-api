<?php // EMPTY - MOVED TO USER PROFILE ?>
<?php header('Location: ' . osc_user_profile_url()); ?>