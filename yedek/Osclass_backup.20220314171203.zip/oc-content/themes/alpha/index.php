<?php
/*
Theme Name: Alpha Osclass Theme
Theme URI: https://osclasspoint.com/osclass-themes/general/alpha-osclass-theme_i98
Description: Fast and eye-catching osclass premium theme
Version: 1.5.3
Author: MB Themes
Author URI: https://osclasspoint.com
Widgets: header,footer
Theme update URI: alpha-osclass-theme
Product Key: pBrd68M4b5SiexjdJ5yK
*/
?>