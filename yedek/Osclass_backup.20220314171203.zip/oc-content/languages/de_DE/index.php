<?php
function locale_de_DE_info() {
  return array(
     'name'            => 'German'
    ,'short_name'      => 'German'
    ,'description'     => 'German translation'
    ,'version'         => '3.4.0'
    ,'author_name'     => 'OsclassPoint'
    ,'author_url'      => 'https://osclass.osclasspoint.com/'
    ,'currency_format' => '{NUMBER} {CURRENCY}'
    ,'date_format'     => 'm/d/Y'
    ,'stop_words'      => ''
  );
}
?>