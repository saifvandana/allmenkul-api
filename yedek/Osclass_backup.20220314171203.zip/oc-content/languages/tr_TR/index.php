<?php
function locale_tr_TR_info() {
  return array(
     'name'            => 'Turkish'
    ,'short_name'      => 'Turkish'
    ,'description'     => 'Turkish translation'
    ,'version'         => '3.3.0'
    ,'author_name'     => 'OsclassPoint'
    ,'author_url'      => 'https://osclass.osclasspoint.com/'
    ,'currency_format' => '{NUMBER} {CURRENCY}'
    ,'date_format'     => 'm/d/Y'
    ,'stop_words'      => ''
  );
}
?>